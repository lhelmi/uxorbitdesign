public class FoodsDemo {
    public static void main(String[] args) {
        // write your code here
        Foods foods = Foods.getFoods();
        //perintah ini akan mendapatkan objek yang sama
        Foods foods2 = Foods.getFoods();

        //dua perintah ini sama
        foods.doSomething();
        foods2.doSomething();

    }
}
