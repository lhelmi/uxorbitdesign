public class Foods {
    //atribut
    private static Foods foods;

    //method
    //konstruktor
    private Foods(){
        System.out.println("Hai, saya foods.");
    }

    //ini hook
    public static synchronized Foods getFoods(){
        if(foods ==null){
            foods =new Foods();
        }

        return foods;
    }

    public void doSomething(){
        System.out.println("Foods ini enak.");
    }
}
